import tkinter as tk
from turtle import back
from PIL import Image
from PIL import ImageTk
from tkinter.filedialog import askopenfilename
import process

#            GLOBAL VARIABLES
file = ''
image = None

on_selecting_A = False
on_selecting_B = False






#            FUNCTIONS

def ask_open_file():
    global file, image, lblImage, viewport

    file = askopenfilename(filetypes=[("Image files","*.bmp *.png *.jpg *.webp")])

    if len(file) == 0:
        return
    
    image = Image.open(file)
    image1 = ImageTk.PhotoImage(image)

    lblImage = tk.Label(master=viewport, image=image1, borderwidth=5)
    lblImage.image = image1
    lblImage.grid(row= 1, column=1 , rowspan= 13, columnspan= 3, padx=20, pady=20)


def on_scale_brightness_changed(value):
    global image, lblImage, viewport

    value = int(value)
    t_image = process.adjust_brightness(image, value)
    image1 = ImageTk.PhotoImage(t_image)

    lblImage = tk.Label(master=viewport, image=image1, borderwidth=5)
    lblImage.image = image1
    lblImage.grid(row= 1, column=1 , rowspan= 13, columnspan= 3, padx=20, pady=20)

def on_extract_red_press():
    global image, lblImage, viewport

    t_image = process.extract_channel(image, 'r')
    image1 = ImageTk.PhotoImage(t_image)

    lblImage = tk.Label(master=viewport, image=image1, borderwidth=5)
    lblImage.image = image1
    lblImage.grid(row= 1, column=1 , rowspan= 13, columnspan= 3, padx=20, pady=20)
  
def on_extract_green_press():
    global image, lblImage, viewport

    t_image = process.extract_channel(image, 'g')
    image1 = ImageTk.PhotoImage(t_image)

    lblImage = tk.Label(master=viewport, image=image1, borderwidth=5)
    lblImage.image = image1
    lblImage.grid(row= 1, column=1 , rowspan= 13, columnspan= 3, padx=20, pady=20)
    

def on_extract_blue_press():
    global image, lblImage, viewport

    t_image = process.extract_channel(image, 'b')
    image1 = ImageTk.PhotoImage(t_image)

    lblImage = tk.Label(master=viewport, image=image1, borderwidth=5)
    lblImage.image = image1
    lblImage.grid(row= 1, column=1 , rowspan= 13, columnspan= 3, padx=20, pady=20)

def on_extract_original_press():
    global image, lblImage, viewport

    t_image = process.extract_channel(image, 'rgb')
    image1 = ImageTk.PhotoImage(t_image)

    lblImage = tk.Label(master=viewport, image=image1, borderwidth=5)
    lblImage.image = image1
    lblImage.grid(row= 1, column=1 , rowspan= 13, columnspan= 3, padx=20, pady=20)

def on_crop_A_pressed():
    global on_selecting_A, on_selecting_B
    on_selecting_A = True
    on_selecting_B = False

def on_crop_B_pressed():
    global on_selecting_A, on_selecting_B
    on_selecting_A = False
    on_selecting_B = True

def screen_position_to_image_position(screen_position):
    global image, viewport

    viewport_width = viewport.winfo_width()
    viewport_height = viewport.winfo_height()

    image_width = image.width
    image_height = image.height

    print(screen_position)
    print(viewport_width, viewport_height)
    print(image_width, image_height)

    top_left_image = (int(0.5 * (viewport_width - image_width)), \
                      int(0.5 * (viewport_height - image_height)))
    
    image_position = (screen_position[0] - top_left_image[0], \
                      screen_position[1] - top_left_image[1])

    return image_position

def handle_mouse_click(event):
    global on_selecting_A, on_selecting_B, image, viewport, lblImage
    print(event)

    # it means you just clicked crop A
    if on_selecting_A:
        on_selecting_A = False

        img_pos = screen_position_to_image_position((event.x, event.y))

        print(img_pos)
        t_image = process.render_line(image, 'h', img_pos[1], (255, 0, 0))
        t_image = process.render_line(t_image, 'v', img_pos[0], (255, 0, 0))
        image1 = ImageTk.PhotoImage(t_image)

        lblImage = tk.Label(master=viewport, image=image1, borderwidth=5)
        lblImage.image = image1
        lblImage.grid(row= 1, column=1 , rowspan= 13, columnspan= 3, padx=20, pady=20)


    elif on_selecting_B:
        print(event)
        on_selecting_B = False
        

#            UI

window = tk.Tk()

viewport = tk.Frame(width=800, height=600, background='yellow')
viewport.pack(side=tk.LEFT)

buttonFrame = tk.Frame(width=400, height=600)
buttonFrame.pack(side=tk.LEFT)

btn_open = tk.Button(master = buttonFrame, text='open', command=ask_open_file)
btn_open.place(x=10, y=10)

lblLabel = tk.Label(master=buttonFrame, text='Brightness')
lblLabel.place(x = 10, y = 65)

s_adjust_brightness = tk.Scale(master = buttonFrame, from_ = -100, to = 100, tickinterval= 1, orient=tk.HORIZONTAL, command=on_scale_brightness_changed)
s_adjust_brightness.place(x = 100, y = 50)

btn_extract_red = tk.Button(master=buttonFrame, text='extract red', command=on_extract_red_press)
btn_extract_red.place(x = 10, y = 110)

btn_extract_green = tk.Button(master=buttonFrame, text='extract green', command=on_extract_green_press)
btn_extract_green.place(x = 10, y = 140)

btn_extract_blue = tk.Button(master=buttonFrame, text='extract blue', command=on_extract_blue_press)
btn_extract_blue.place(x = 10, y = 170)

btn_extract_original = tk.Button(master=buttonFrame, text='original', command=on_extract_original_press)
btn_extract_original.place(x = 10, y = 200)

btn_crop_A = tk.Button(master=buttonFrame, text = 'Crop A', command=on_crop_A_pressed)
btn_crop_A.place(x = 10, y = 230)
btn_crop_A = tk.Button(master=buttonFrame, text = 'Crop B', command=on_crop_B_pressed)
btn_crop_A.place(x = 70, y = 230)

window.bind("<Button-1>", handle_mouse_click)

window.mainloop()