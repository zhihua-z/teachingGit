'''
在这里写一个服务
这个服务是一堆的function
我们可以使用这些function来编辑照片
'''

# 引入pillow库
from PIL import Image

def pixel_add(p, v):
   return (p[0] + v[0], p[1] + v[1], p[2] + v[2])

def pixel_strength(p):
   return p[0] + p[1] + p[2]

'''
接收一个图片的路径
然后把这张照片显示出来
'''
def show_image(path):
    img = Image.open(path)
    img.show()

    return img

def adjust_brightness(img, val):
  t_img = img.copy()

  '''
  这个是这张照片的像素信息，但是照片的像素信息都是以1D列表的格式储存的
  '''
  for yi in range(t_img.height):
      for xi in range(t_img.width):
          p = t_img.getpixel((xi, yi))

          p = pixel_add(p, (val, val, val))

          t_img.putpixel((xi, yi), p)

  return t_img

def crop(path, x1, y1, x2, y2, result_path):
  img = Image.open(path)
  img_result = Image.new(mode = 'RGB', size = (x2 - x1, y2 - y1))

  # 1. shift x1, y1 to be my new (0, 0) position
  for yi in range(y1, y2):
     for xi in range(x1, x2):
        p = img.getpixel((xi, yi))
        img_result.putpixel((xi - x1, yi - y1), p)
        
  img_result.show()
  return img


def inverse_crop(path, x1, y1, x2, y2, result_path):
    img = Image.open(path)
    
    for yi in range(y1, y2):
        for xi in range(x1, x2):
            img.putpixel((xi, yi), (0, 0, 0))  # Set pixel to black

    img.save(result_path)
    img.show()
    return img



def adjust_shadow(path, val):
  img = Image.open(path)

  for yi in range(img.height):
    for xi in range(img.width):
      p = img.getpixel((xi, yi))
      s = pixel_strength(p)

      # (50, 25, 24) (50, 25, 25)
      # (100, 75, 74) (50, 25, 25)
      if s < 100:
        newval = int(val * (abs(s - 100) / 100))
        p = pixel_add(p, (newval, newval, newval))
  
      img.putpixel((xi, yi), p)
  
  img.show()
  return img

'''
channel can be 'r', 'g', 'b', 'a'
'''
def extract_channel(img, channel):
    img_t = Image.new('RGB', (img.width, img.height))
    
    for yi in range(img.height):
      for xi in range(img.width):
          p = img.getpixel((xi, yi))
          val = (0, 0, 0)
          if channel == 'r':
             val = (p[0], 0, 0)
          elif channel == 'g':
             val = (0, p[1], 0)
          elif channel == 'b':
             val = (0, 0, p[2])
          elif channel == 'rgb':
             val = p

          img_t.putpixel((xi, yi), val)
      
    return img_t

def render_line(img, mode, val, color):
    img_t = img.copy()
    
    for yi in range(img.height):
        for xi in range(img.width):
            if mode == 'h':
               if yi == val:
                  img_t.putpixel((xi, yi), color)
            elif mode == 'v':
               if xi == val:
                  img_t.putpixel((xi, yi), color)
      
    return img_t




# homework
# adjust highlight

# google on how to adjust gamma