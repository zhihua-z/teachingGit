import tkinter as tk
from PIL import Image
from PIL import ImageTk
from tkinter.filedialog import askopenfilename
import process

class Layer:
    def __init__(self, img = None):
        self.image = img
        self.brightness_val = 0
        
        self.result_image = None
        
    def render(self):
        self.result_image = process.adjust_brightness(self.image, self.brightness_val)
        return self.result_image

class Button:
  pass

class Panel:
  def __init__(self, app):
    self.app = app
    self.comp_list = []
  
  def destroy(self):
    for x in self.comp_list:
      x.destroy()
    
  def register(self, comp):
    self.comp_list.append(comp)
    
  

class Application:
    def __init__(self):
        self.filename = ''
        self.original_image = None
        self.current_image = None
        
        self.layer = []
        self.current_layer_index = None;
        
        self.crop_A_layer = None
        self.crop_B_layer = None
        
        self.lblImage = None
        self.on_selecting_A = False
        self.on_selecting_B = False
        
        self.control_down = False
        
        self.viewport_width = 0
        self.viewport_height = 0
        
        # maintain两个list，一个是viewport里全部的组件
        # 一个是button frame里全部的组件
        self.vp_list = []
        self.bf_list = []
        
        self.adjust_panel = Panel(self)
        
    def register(self, frame, tkComp):
      if frame == self.buttonFrame:
        self.adjust_panel.register(tkComp)
      elif frame == self.viewport:
        self.vp_list.append(tkComp)

    def setup(self):
        
        self.window = tk.Tk()

        self.viewport = tk.Frame(width=800, height=600)
        self.viewport.pack(side=tk.LEFT)
        self.viewport_width = 800
        self.viewport_height = 600

        self.buttonFrame = tk.Frame(width=400, height=600)
        self.buttonFrame.pack(side=tk.LEFT)
        
        self.btn_clear = tk.Button(master=self.buttonFrame, text='clear', command=self.testclear)
        self.btn_clear.place(x = 10, y = 300)
        
        self.btn_adjust_panel = tk.Button(master=self.buttonFrame, text='adjust panel', command=self.testcreate)
        self.btn_adjust_panel.place(x = 100, y = 300)

        self.window.bind("<Button-1>", self.handle_mouse_click)
        self.window.bind('<KeyPress>',self.key_press)
        self.window.bind('<KeyRelease>',self.key_released )
        
    def setup_adjust_panel(self):
      
        self.adjust_panel.btn_open = tk.Button(master = self.buttonFrame, text='open', command=self.ask_open_file)
        self.adjust_panel.btn_open.place(x=10, y=10)
        self.register(self.buttonFrame, self.adjust_panel.btn_open)
        
        # self.button_A = Button(self.adjust_panel, 'open', self.ask_open_file, (10, 10))
                
        self.adjust_panel.lblLabel = tk.Label(master=self.buttonFrame, text='Brightness')
        self.adjust_panel.lblLabel.place(x = 10, y = 65)
        self.register(self.buttonFrame, self.adjust_panel.lblLabel)

        self.adjust_panel.s_adjust_brightness = tk.Scale(master = self.buttonFrame, from_ = -100, to = 100, tickinterval= 1, orient=tk.HORIZONTAL, command=self.on_scale_brightness_changed)
        self.adjust_panel.s_adjust_brightness.place(x = 100, y = 50)
        self.register(self.buttonFrame, self.adjust_panel.s_adjust_brightness)

        self.adjust_panel.btn_extract_red = tk.Button(master=self.buttonFrame, text='extract red', command=self.on_extract_red_press)
        self.adjust_panel.btn_extract_red.place(x = 10, y = 110)
        self.register(self.buttonFrame, self.adjust_panel.btn_extract_red)

        self.adjust_panel.btn_extract_green = tk.Button(master=self.buttonFrame, text='extract green', command=self.on_extract_green_press)
        self.adjust_panel.btn_extract_green.place(x = 10, y = 140)
        self.register(self.buttonFrame, self.adjust_panel.btn_extract_green)

        self.adjust_panel.btn_extract_blue = tk.Button(master=self.buttonFrame, text='extract blue', command=self.on_extract_blue_press)
        self.adjust_panel.btn_extract_blue.place(x = 10, y = 170)
        self.register(self.buttonFrame, self.adjust_panel.btn_extract_blue)

        self.adjust_panel.btn_extract_original = tk.Button(master=self.buttonFrame, text='original', command=self.on_extract_original_press)
        self.adjust_panel.btn_extract_original.place(x = 10, y = 200)
        self.register(self.buttonFrame, self.adjust_panel.btn_extract_original)

        self.adjust_panel.btn_crop_A = tk.Button(master=self.buttonFrame, text = 'Crop A', command=self.on_crop_A_pressed)
        self.adjust_panel.btn_crop_A.place(x = 10, y = 230)
        self.adjust_panel.btn_crop_B = tk.Button(master=self.buttonFrame, text = 'Crop B', command=self.on_crop_B_pressed)
        self.adjust_panel.btn_crop_B.place(x = 70, y = 230)
        self.register(self.buttonFrame, self.adjust_panel.btn_crop_A)
        self.register(self.buttonFrame, self.adjust_panel.btn_crop_B)

        self.adjust_panel.btn_adjust_shadow = tk.Button(master=self.buttonFrame,text= 'adjust_shadow',command= process.adjust_shadow)
        self.adjust_panel.btn_adjust_shadow.place(x = 10, y = 260)
        self.register(self.buttonFrame, self.adjust_panel.btn_adjust_shadow)

        self.adjust_panel.btn_adjust_hightlight = tk.Button(master=self.buttonFrame,text= 'adjust_hightlight',command= process.adjust_hightlight)
        self.adjust_panel.btn_adjust_hightlight.place(x = 90, y = 260)
        self.register(self.buttonFrame, self.adjust_panel.btn_adjust_hightlight)
    
    def testclear(self):
      self.adjust_panel.destroy()
    
    def testcreate(self):
      self.setup_adjust_panel()  
    
    def key_press(self, event):
      print(event)
      
    def key_released(self, event):
      print(event)
    
    def update(self):
        self.window.mainloop()
        
    def update_render(self):
        layer = self.layer[self.current_layer_index]
        
        result_image = layer.render()
        
        if self.crop_A_layer is not None and self.crop_B_layer is not None:
            merged_crop_image = process.merge_crop(self.crop_A_layer.image, self.crop_B_layer.image)
            result_image = process.render_crop(result_image, merged_crop_image)
        elif self.crop_A_layer is not None:
            result_image = process.render_crop(result_image, self.crop_A_layer.image)
        elif self.crop_B_layer is not None:
            result_image = process.render_crop(result_image, self.crop_B_layer.image)
        
        
        self.render_image(result_image)
        
    def destroy_if_have(self, component):
        if len(self.filename) != 0 and component is not None:
            component.destroy()
        
    def ask_open_file(self):
        self.filename = askopenfilename(filetypes=[("Image files","*.bmp *.png *.jpg *.webp")])

        if len(self.filename) == 0:
            return
        
        self.original_image = Image.open(self.filename)
        
        # 如果我的照片横向纵向都比viewport小，我就需要调大这张照片
        # 如果我的照片横向或者纵向比viewport大，我就需要根据一个比例来调整
        # 调整的目标是：最大的那条边满足于屏幕的大小 800 x 600
        
        # 如果我的照片横向是1000，纵向是1500，我的屏幕尺寸是800x600，那我应该怎样调整？
        
        # 找比较长的边
        if (self.original_image.width > self.original_image.height):
          # 调整横边
          ratio = self.viewport_width / self.original_image.width
        else:
          # 调整竖边
          ratio = self.viewport_height / self.original_image.height
        new_sz = (round(self.original_image.width * ratio), round(self.original_image.height * ratio))
        self.original_image = self.original_image.resize(new_sz, resample = Image.Resampling.BICUBIC)
        self.current_image = self.original_image
        
        # 管理layer
        l = Layer(self.original_image)
        
        # 删掉之前的layer
        self.layer = self.layer[:-1]
        self.layer.append(l)
        self.current_layer_index = 0

        self.render_image(self.original_image)

    def render_image(self, image):
        # 清理垃圾
        self.destroy_if_have(self.lblImage)
        image1 = ImageTk.PhotoImage(image)
        self.lblImage = tk.Label(master=self.viewport, image=image1)
        self.lblImage.image = image1
        
        # 调整照片的位置让它居中
        mid_x_pos, mid_y_pos = 0, 0
        if (self.original_image.width > self.original_image.height):
          mid_y_pos = self.viewport_height / 2 - self.original_image.height / 2 - 1
        else:
          mid_x_pos = self.viewport_width / 2 - self.original_image.width / 2 - 1
          
        
        self.lblImage.place(x = mid_x_pos, y = mid_y_pos)
        self.register(self.viewport, self.lblImage)

    def update_current_layer(self, id):
        self.current_layer_index = id

    def on_scale_brightness_changed(self, value):
        value = int(value)
        current_layer = self.layer[self.current_layer_index]
        current_layer.brightness_val = value

        self.update_render()

    def on_extract_red_press(self):
        self.current_image = process.extract_channel(self.original_image, 'r')
        self.render_image(self.current_image)
    
    def on_extract_green_press(self):
        self.current_image = process.extract_channel(self.original_image, 'g')
        self.render_image(self.current_image)
        

    def on_extract_blue_press(self):
        self.current_image = process.extract_channel(self.original_image, 'b')
        self.render_image(self.current_image)

    def on_extract_original_press(self):
        self.current_image = process.extract_channel(self.original_image, 'rgb')
        self.render_image(self.current_image)

    def on_crop_A_pressed(self):
        self.on_selecting_A = True
        self.on_selecting_B = False

    def on_crop_B_pressed(self):
        self.on_selecting_A = False
        self.on_selecting_B = True

    def screen_position_to_image_position(self, screen_position):
        viewport_width = self.viewport.winfo_width()
        viewport_height = self.viewport.winfo_height()

        image_width = self.original_image.width
        image_height = self.original_image.height

        top_left_image = (int(0.5 * (viewport_width - image_width)), \
                        int(0.5 * (viewport_height - image_height)))
        
        image_position = (screen_position[0] - top_left_image[0], \
                        screen_position[1] - top_left_image[1])
        
        return image_position

    def handle_mouse_click(self, event):
        # it means you just clicked crop A
        if self.on_selecting_A:
            self.on_selecting_A = False

            img_pos = self.screen_position_to_image_position((event.x, event.y))

            current_layer = self.layer[self.current_layer_index]
            self.crop_A_layer = Layer()
            self.crop_A_layer.image = process.create_crop_layer(current_layer.image, 'h', img_pos[1], 'A', True)
            self.crop_A_layer.image = process.create_crop_layer(self.crop_A_layer.image, 'v', img_pos[0], 'A', False)

            self.update_render()
        elif self.on_selecting_B:
            self.on_selecting_B = False

            img_pos = self.screen_position_to_image_position((event.x, event.y))

            current_layer = self.layer[self.current_layer_index]
            self.crop_B_layer = Layer()
            self.crop_B_layer.image = process.create_crop_layer(current_layer.image, 'h', img_pos[1], 'B', True)
            self.crop_B_layer.image = process.create_crop_layer(self.crop_B_layer.image, 'v', img_pos[0], 'B', False)
 
            self.update_render()
