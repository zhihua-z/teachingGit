from app import App

app1 = App()
app1.draw()