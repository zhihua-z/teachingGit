
def add(a, b):
    return (a + b)

add_1 = lambda x, y : x + y
    
result = add_1(1, 2)
print(result)
