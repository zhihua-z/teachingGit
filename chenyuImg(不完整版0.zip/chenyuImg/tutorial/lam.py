
def func(x:int, y:float):
    return x + y

def printgg(y, x=20):
    print(y, x)

myadd = lambda x=1, y=5 : x + y

print(myadd())
