# maintain all the styles of your application

app_bar_background = '#2b2b2b'
app_background = '#2a2c31'
light_text_color = '#dddddd'