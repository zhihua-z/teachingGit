from App import App

app = App()
app.draw()
app.run()