/*
这是一个头文件 .h header

它会声明很多的function，所以我们可以在别的地方使用这些functions
*/

void mystrcpy(char * destination, char * source);