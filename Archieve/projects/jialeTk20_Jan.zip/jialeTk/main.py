from Game import Game
from App import App

app = App()
app.load()


# game = Game('juese.json', 'zhaoshu.json', 'zhuangbei.json')

# 玩游戏的过程等下再说

# game.save()



# 作业 1
# 使用json去加载技能和角色

# 作业 2
# 给每个角色加一个新的class 消耗品
# 比如 ： 魔法药水 生命药水 苹果 面包 攻击药水