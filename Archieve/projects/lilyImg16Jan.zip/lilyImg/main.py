from App import App


app = App()
app.run()
